<?php 
// Configuration Variables Set Here
$ENV_Variables = array(
    "baseUrl" => "https://196.188.120.3:38443/apiaccess/payment/gateway",
    "fabricAppId" => "c4182ef8-9249-458a-985e-06d191f4d505",
    "appSecret" => "fad0f06383c6297f545876694b974599",
    "merchantAppId" => "930231098009602",
    "merchantCode" =>  "101011"
);
