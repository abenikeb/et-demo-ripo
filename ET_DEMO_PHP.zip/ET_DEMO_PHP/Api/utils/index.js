`
appid=965919477137301
&merch_code=500284
&nonce_str=fcab0d2949e64a69a212aa83eab6ee1d
&prepay_id=008ae22e8df0157f720a7f7f2d1c5804a34002
&timestamp=1679060672
&sign=FruM7x9XSS3WwRiEdU8wIQbrTzb8fliXl3Z1GJoFIz96RiOM0sn70Q5mmjQW0IriBJzDZIRNjbRWvjho/l/rvaq2yXHtK1DG1I6CLSBtcRll3fXe4SmQLgqQvSQgUiP2n6jpu+0h6PlLW8yAoftx3XadbTdUkkYO4AKPXyeJz23xGJgkFK34+/tC2/tXrFaWtOipfi1R2uSuplEat4sPvICaOiDIrFLnFCAbARG+czl7nFDF7J73f9Za/jgjBaFhB3ORHaZhbY8lHVF4BLOuTDC5t6/FuFQmRZJN1sQC2fut026V28dvnPtpvvxA8dnnY8Be3UryUkXPP+Ze7oPKlg==
sign_type=SHA256WithRSA

`;

rawRequest.trim().replaceAll(/["-]/g, "")